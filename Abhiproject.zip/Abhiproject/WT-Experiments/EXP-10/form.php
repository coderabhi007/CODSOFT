<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Student Information Form</title>
</head>
<body>
 <h1>Student Information Form</h1>
 <div class="forms">
 <form action="form.php" method="POST">
 <label for="rollno">RollNo = </label>
 <input type="number" name="rollno">
 <br><br>
 <label for="name">Name = </label>
 <input type="text" name="name">
 <br><br>
 <label for="city">City = </label>
 <input type="text" name="city">
 <br><br>
 <input type="submit" name="submit" value="Submit">
 <br><br>
 </form>
 </div>
</body>
</html>
<?php
 // Creating connection
 $servername = "localhost"; 
 $username = "root"; 
 $password = ""; 
 $database = "sintu"; 
 $conn = mysqli_connect($servername, $username, $password, $database); 
 if(!$conn) { 
 die("Failed to connect! Reason: " . mysqli_connect_error()); 
 } 
 echo "<br>Connection successful<br>"; 
 // Creating table
 $sql = "CREATE TABLE IF NOT EXISTS studentinfo (rollno INT PRIMARY KEY, name
VARCHAR(20), city VARCHAR(20))"; 
 $query_result = mysqli_query($conn, $sql); 
 if($query_result) { 
 echo "Table created successfully<br>"; 
 } else { 
 echo "Table not created ->"; 
 } 
 
 // Getting form data
 if(isset($_POST['submit'])) { 
 $Rollno = $_POST['rollno']; 
 $Name = $_POST['name']; 
 $City = $_POST['city']; 
 
 // Inserting data into database
 $sql = "INSERT INTO studentinfo (rollno, name, city) VALUES ('$Rollno', 
'$Name', '$City')"; 
 
 $insertion_result = mysqli_query($conn, $sql); 
 if($insertion_result) { 
 echo "<br>Insertion into database is successful"; 
 } else { 
 echo "Data not inserted. Reason: " . mysqli_error($conn); 
 } 
 } 
 // Fetching data
 // Writing SQL query 
 $sql = "SELECT * FROM studentinfo"; 
 $query_result = mysqli_query($conn, $sql); 
 if($query_result) { 
 echo "Query executed successfully<br>"; 
 $row_count_in_table = mysqli_num_rows($query_result); 
 echo "Row count = ". $row_count_in_table. "<br>"; 
 // Displaying query results
 while($row = mysqli_fetch_assoc($query_result)) { 
 echo "RollNo. = ".$row['rollno']. " | Name = ". $row['name']. " | City 
= ". $row['city']. "<br>"; 
 } 
 } else { 
 echo "We are facing some error while retrieving records<br>"; 
 } 
 mysqli_close($conn); 
?>