<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>PHP Session Demo</title>
 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="text-center"><h2>PHP SESSION</h2></div>
    <?php
 // Start the session
        session_start(); 
 // Check if the user is logged in
        if(isset($_SESSION['username'])) { 
            echo "<div class='alert alert-success' role='alert'>Welcome back, " . $_SESSION['username'] . 
                        "! <a href='logout.php' class='alert-link'>Logout</a></div>"; 
        } else { 
 // If not logged in, show login form
        echo "<form action='login.php' method='post'>"; 
        echo "<div class='form-group'>"; 
        echo "<label for='username'>Username:</label>"; 
        echo "<input type='text' class='form-control' id='username' name='username'>"; 
        echo "</div>"; 
        echo "<div class='form-group'>"; 
        echo "<label for='password'>Password:</label>"; 
        echo "<input type='password' class='form-control' id='password' name='password'>"; 
        echo "</div>"; 
        echo "<button type='submit' class='btn btn-primary'>Login</button>"; 
        echo "</form>"; 
    } 
 ?>
 </div>
 </div>
 </div>
</body>
</html>
