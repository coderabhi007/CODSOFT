<?php
// Start the session
session_start(); 
// Hardcoded username and password for demonstration purposes
$valid_username = "user"; 
$valid_password = "password"; 
// Check if form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") { 
 $username = $_POST['username']; 
 $password = $_POST['password']; 
 // Validate username and password
 if($username == $valid_username && $password == $valid_password) { 
 // Set session variables
 $_SESSION['username'] = $username; 
 echo "
 <script>
 alert('login successful');
 window.location.href = 'form.php';
 </script>"; 
 } else { 
 echo "
 <script>
 alert('login failed. use correct password and username');
 window.location.href = 'form.php';
 </script>"; 
 } 
} 
?>