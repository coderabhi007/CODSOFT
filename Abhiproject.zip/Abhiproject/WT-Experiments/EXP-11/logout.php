<?php
session_start(); // Start the session
session_unset(); // Unset all session variables
session_destroy(); // Destroy the session
echo "<script>
 alert('Logout successful');
 window.location.href = 'form.php';
 </script>"; 
?>