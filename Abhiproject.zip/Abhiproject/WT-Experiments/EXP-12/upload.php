<?php
$targetDir = "uploads/"; // Directory where files will be uploaded
$targetFile = $targetDir . basename($_FILES["fileToUpload"]["name"]); // Path to save the uploaded file
$uploadOk = 1; // Flag to check if the file was uploaded successfully
$imageFileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION)); // Get the file extension
// Check if file already exists
if (file_exists($targetFile)) { 
 
 echo "<script>
 alert('Sorry, file already exists');
 window.location.href = 'form.php';
 </script>"; 
 $uploadOk = 0; 
} 
// Allow only certain file formats
$allowedExtensions = array("jpg", "jpeg", "png", "gif"); // Add more extensions if needed
if (!in_array($imageFileType, $allowedExtensions)) { 
 
 echo "<script>
 alert('Sorry, only JPG, JPEG, PNG, GIF files are allowed.');
 window.location.href = 'form.php';
 </script>"; 
 $uploadOk = 0; 
} 
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) { 
 echo "Sorry, your file was not uploaded."; 
} else { 
 if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) { 
 echo "<script>
 alert('The file ". basename($_FILES['fileToUpload']['name']). " has been uploaded.');
 window.location.href = 'form.php';
 </script>"; 
 } else { 
 echo "<script>
 alert('Sorry, there was an error uploading your file.');
 window.location.href = 'form.php';
 </script>"; 
 } 
} 
?>
